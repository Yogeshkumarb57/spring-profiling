package handzap.firstProj.rest;

import handzap.firstProj.Article;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/newspaper/article")
public class NewspaperArticleRest {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Article searchNewspaperArticleData(@QueryParam("queryType") String queryType, @QueryParam("queryValue") String queryValue) {
        Article article = new Article("test", "test", "test");
        return article;
    }
}
