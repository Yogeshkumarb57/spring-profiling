package handzap.firstProj;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try {
    		Document doc = Jsoup.connect("https://www.thehindu.com/archive/").get();
        	Elements newsHeadlines = doc.getElementsByClass("archiveBorder");
        	List<String> authors = new ArrayList<String>();
        	List<Article> allArticles = new ArrayList<Article>();
        	boolean sizeDone = false;
        	for (Element headline : newsHeadlines) 
        	{
        	  Elements thisYear = headline.getElementsByClass("archiveMonthList");
        	  for(Element thisYearList : thisYear)
        	  {
        		  Elements allMonths = thisYearList.getElementsByTag("a");
        		  for(Element thisMonth : allMonths)
        		  {
        			  if(thisMonth.absUrl("href").toString().contains("/archive/web/"))
        			  {
        				  Document thisMonthDoc = Jsoup.connect(thisMonth.absUrl("href")).get();
        				  Elements tableDatas = thisMonthDoc.getElementsByClass("archiveTable");
        				  for(Element tableData : tableDatas)
        				  {
        					  Elements allDates = tableData.getElementsByClass("ui-state-default");
        					  for(Element thisDate : allDates)
            				  {
        						  Document thisdateDoc = Jsoup.connect(thisDate.absUrl("href")).get();
        						  
        						  Elements allTitleLink = thisdateDoc.getElementsByTag("a");
                				  for(Element titleLink : allTitleLink)
                				  {
                					  if(titleLink.absUrl("href").endsWith(".ece"))
                					  {
                						  String title = titleLink.text();
                						  Document thisTitleDoc = Jsoup.connect(titleLink.absUrl("href")).get();
                						  Element authorElement = thisTitleDoc.getElementsByClass("mobile-author").first().getElementsByTag("a").first();
                						  String authorName = authorElement!=null ? authorElement.text() : "unknown";
                						  if(!authors.contains(authorName))
                						  {
                							  authors.add(authorName);
                						  }
                						  Elements allParagraphTag = thisTitleDoc.getElementsByTag("p");
                						  String description = "";
                        				  for(Element thisParagraph : allParagraphTag)
                        				  {
                        					  description += "<p>"+thisParagraph.text()+"</p>";
                        				  }
                        				  Article article = new Article(authorName, title, description);
                        				  allArticles.add(article);
                        				  if(allArticles.size()==100)
                        				  {
                        					  sizeDone = true;
                        					  break;
                        				  }
                					  }
                				  }
                				  if(sizeDone)
                					  break;
            				  }
        					  if(sizeDone)
            					  break;
        				  }
        			  }
        			  if(sizeDone)
    					  break;
        		  }
        		  if(sizeDone)
					  break;
        	  }
        	  if(sizeDone)
				  break;
        	}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
